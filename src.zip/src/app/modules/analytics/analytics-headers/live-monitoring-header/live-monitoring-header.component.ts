import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-live-monitoring-header',
  templateUrl: './live-monitoring-header.component.html',
  styleUrls: ['./live-monitoring-header.component.scss']
})
export class LiveMonitoringHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
