import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-executive-dashboard-header',
  templateUrl: './executive-dashboard-header.component.html',
  styleUrls: ['./executive-dashboard-header.component.scss']
})
export class ExecutiveDashboardHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
