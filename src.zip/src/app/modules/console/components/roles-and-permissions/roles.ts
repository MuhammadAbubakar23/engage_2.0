export interface Roles {
    Name:string;
    link: any;
    parentId:any;
    baseId?:string;
    Icon?:string ;
    typeOf?:string;
    indexNo?:string;
}
