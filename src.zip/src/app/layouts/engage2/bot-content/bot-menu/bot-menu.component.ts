import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'bot-menu',
  templateUrl: './bot-menu.component.html',
  styleUrls: ['./bot-menu.component.scss']
})
export class BotMenuComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
