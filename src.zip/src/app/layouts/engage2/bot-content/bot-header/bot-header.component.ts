import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'bot-header',
  templateUrl: './bot-header.component.html',
  styleUrls: ['./bot-header.component.scss']
})
export class BotHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
