import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'overlay-right-panel-selection',
  templateUrl: './overlay-right-panel-selection.component.html',
  styleUrls: ['./overlay-right-panel-selection.component.scss']
})
export class OverlayRightPanelSelectionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
