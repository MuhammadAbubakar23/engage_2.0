import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'overlay-right-panel-list',
  templateUrl: './overlay-right-panel-list.component.html',
  styleUrls: ['./overlay-right-panel-list.component.scss']
})
export class OverlayRightPanelListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
