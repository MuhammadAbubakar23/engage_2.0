import { ConsoleTableVisibilityPipe } from './console-table-visibility.pipe';

describe('ConsoleTableVisibilityPipe', () => {
  it('create an instance', () => {
    const pipe = new ConsoleTableVisibilityPipe();
    expect(pipe).toBeTruthy();
  });
});
