import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-console-table-columns',
  templateUrl: './console-table-columns.component.html',
  styleUrls: ['./console-table-columns.component.scss']
})
export class ConsoleTableColumnsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
