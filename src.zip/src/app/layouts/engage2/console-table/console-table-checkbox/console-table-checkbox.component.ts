import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-console-table-checkbox',
  templateUrl: './console-table-checkbox.component.html',
  styleUrls: ['./console-table-checkbox.component.scss']
})
export class ConsoleTableCheckboxComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
