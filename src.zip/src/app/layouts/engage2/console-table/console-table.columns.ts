export interface ConsoleTableColumns {
    Name:string;
    Data:{};
    Type?:string,
    Sorting?:string,
    Searching?:boolean,
}
