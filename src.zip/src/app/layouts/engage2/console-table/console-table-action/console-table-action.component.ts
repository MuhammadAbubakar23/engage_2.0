import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-console-table-action',
  templateUrl: './console-table-action.component.html',
  styleUrls: ['./console-table-action.component.scss']
})
export class ConsoleTableActionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
