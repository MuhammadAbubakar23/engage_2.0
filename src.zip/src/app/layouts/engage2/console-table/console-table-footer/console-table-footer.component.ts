import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'console-table-footer',
  templateUrl: './console-table-footer.component.html',
  styleUrls: ['./console-table-footer.component.scss']
})
export class ConsoleTableFooterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
