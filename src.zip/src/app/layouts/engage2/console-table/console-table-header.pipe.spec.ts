import { ConsoleTableHeaderPipe } from './console-table-header.pipe';

describe('ConsoleTableHeaderPipe', () => {
  it('create an instance', () => {
    const pipe = new ConsoleTableHeaderPipe();
    expect(pipe).toBeTruthy();
  });
});
