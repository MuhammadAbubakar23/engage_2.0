import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'console-table-header-checkbox',
  templateUrl: './console-table-header-checkbox.component.html',
  styleUrls: ['./console-table-header-checkbox.component.scss']
})
export class ConsoleTableHeaderCheckboxComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
