import { ConsoleTable } from './console-table.class';

describe('ConsoleTable', () => {
  it('should create an instance', () => {
    expect(new ConsoleTable()).toBeTruthy();
  });
});
