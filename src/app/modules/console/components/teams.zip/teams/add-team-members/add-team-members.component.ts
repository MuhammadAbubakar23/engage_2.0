import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-team-members',
  standalone:true,
  templateUrl: './add-team-members.component.html',
  styleUrls: ['./add-team-members.component.scss']
})
export class AddTeamMembersComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
